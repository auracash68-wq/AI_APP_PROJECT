PRODUCT REQUIREMENTS DOCUMENT (PRD)

Screen Text Assistant — Production Android Application

Document Type: Authoritative Product Requirements Document
Product: Screen Text Assistant
Platform: Android
Minimum Supported Version: Android 10 (API 29), where technically possible
Target: Modern Android versions through Android 16
UI Framework: Kotlin + Jetpack Compose + Material 3
Primary Architecture: AccessibilityService + On-Device OCR + On-Device Translation + Android TextToSpeech
Processing Philosophy: Privacy-first, offline-first, event-driven, resource-efficient

---

1. DOCUMENT AUTHORITY

This PRD is the authoritative product specification for the application.

The AI development agent MUST read and understand this document before implementation.

The agent MUST implement the requirements described here as real Android functionality.

The agent MUST NOT:

- Create a fake prototype.
- Create simulated OCR.
- Create fake translation results.
- Create fake AccessibilityService behavior.
- Create fake permission states.
- Create fake service status.
- Create placeholder functionality.
- Claim functionality that is not actually implemented.
- Silently replace required on-device functionality with cloud AI.
- Add unrelated features.
- Remove explicitly required functionality.
- Bypass Android security restrictions.

If a requirement cannot be implemented exactly because of an Android platform restriction, the agent MUST identify the limitation, implement the best legitimate Android-supported fallback, and never simulate success.

---

2. PRODUCT VISION

Screen Text Assistant is a system-wide Android text utility.

Its purpose is to allow a user to interact with text visible on the Android screen and perform useful actions on that text.

The primary workflow is:

User opens application
        ↓
User grants required permissions
        ↓
Screen Assistant becomes active
        ↓
User opens another Android application
        ↓
User activates text-selection interaction
        ↓
User selects visible text
        ↓
Application detects the text
        ↓
Floating action panel appears
        ↓
┌────────────┬────────────┬──────────┐
│ Translate  │   Listen   │   Copy   │
└────────────┴────────────┴──────────┘

The application must feel like a professional system utility rather than a demonstration application.

---

3. CORE USER VALUE

The application must allow the user to:

1. Detect visible text from supported applications.
2. Select or identify relevant text.
3. Translate the detected text.
4. Listen to the detected text.
5. Copy the detected text.
6. Listen to translated text.
7. Perform these operations with minimal interaction.
8. Keep processing local whenever technically possible.

The application must prioritize:

- Reliability
- Privacy
- Accessibility
- Performance
- Low battery consumption
- Low memory usage
- Android lifecycle correctness
- Graceful failure
- Professional UX
- Maintainability

---

4. CORE FUNCTIONAL REQUIREMENTS

4.1 Text Detection

The application MUST implement real screen-text detection.

The detection architecture MUST use a hybrid strategy.

Primary detection

Use Android "AccessibilityService".

The service should inspect accessible UI content and retrieve:

- Visible text
- Text nodes
- Text bounds
- Selectable information
- Clickable information where relevant
- Focusable information where relevant

Secondary detection

When accessible text is unavailable and Android permits screen capture:

Use:

Permitted Screen Capture
        ↓
Relevant Region
        ↓
On-device OCR
        ↓
Detected Text
        ↓
Bounding Information

The application MUST NOT continuously OCR the entire screen.

---

5. ACCESSIBILITY SERVICE REQUIREMENTS

Implement a real Android "AccessibilityService".

Suggested service name:

ScreenTextAccessibilityService

The service MUST:

- Monitor relevant window changes.
- Inspect "AccessibilityNodeInfo".
- Detect relevant visible text.
- Determine text bounds where available.
- Track relevant user interaction.
- Coordinate the floating interaction layer.
- Correctly handle service lifecycle.
- Release resources correctly.
- Avoid unnecessary processing.

Relevant events may include:

TYPE_WINDOW_STATE_CHANGED
TYPE_WINDOW_CONTENT_CHANGED
TYPE_VIEW_CLICKED
TYPE_VIEW_LONG_CLICKED
TYPE_VIEW_TEXT_CHANGED

Only events that are actually useful should be processed.

The implementation MUST avoid:

- Continuous polling.
- High-frequency full-screen scanning.
- Excessive AccessibilityEvent processing.
- Unnecessary node traversal.
- Memory leaks.
- Battery-draining loops.
- ANR-causing operations.

The service MUST remain lightweight while idle.

---

6. TEXT SELECTION EXPERIENCE

The intended interaction:

User long-presses/selects text
        ↓
Application identifies relevant text
        ↓
Text is represented/highlighted where technically possible
        ↓
Floating action panel appears

The implementation must account for the fact that Android applications expose text differently.

Support:

A. Accessibility text

Use accessible text nodes whenever available.

B. Native selectable text

Use selectable text when the underlying application exposes it.

C. OCR fallback

If text is visually present but unavailable through accessibility APIs, use permitted screen capture and on-device OCR.

The application MUST NOT claim that every application supports direct selection.

---

7. ANDROID SECURITY RESTRICTIONS

The application MUST respect Android security boundaries.

It MUST NOT attempt to bypass:

- "FLAG_SECURE"
- DRM protection
- Banking-app protection
- Authentication protection
- Password protection
- Secure screens
- Protected content
- Android permission restrictions
- Other applications' security mechanisms

If processing is technically prevented, display a professional explanation such as:

«This screen cannot be processed because Android has restricted screen access.»

Never attempt a workaround that violates Android security.

---

8. FLOATING INTERACTION SYSTEM

The application requires a lightweight floating interaction layer.

The overlay MUST:

- Be minimal.
- Be responsive.
- Be touch-friendly.
- Avoid blocking the underlying application.
- Avoid covering the entire screen.
- Allow normal interaction whenever selection mode is not active.

The underlying application should remain usable for:

- Scrolling
- Tapping
- Typing
- Swiping
- Navigation

Interaction interception should only occur when required for the text-selection workflow.

Use Android-supported overlay/accessibility mechanisms.

---

9. FLOATING ACTION PANEL

After successful text detection, display a compact action panel near the selected text.

Required actions:

Translate
Listen
Copy

Example conceptual layout:

┌─────────────────────────────┐
│ Translate │ Listen │ Copy   │
└─────────────────────────────┘

The panel MUST:

- Appear near the detected text.
- Avoid screen boundaries.
- Reposition intelligently.
- Support portrait.
- Support landscape.
- Work across different display sizes.
- Respect gesture-navigation areas.
- Respect status/navigation areas.
- Have rounded corners.
- Have appropriate elevation.
- Have subtle animation.
- Support dynamic font scaling.
- Remain accessible.

It MUST NOT become a full-screen UI.

---

10. INTELLIGENT PANEL POSITIONING

The positioning engine MUST consider the detected text bounds and available display area.

Text near top

Display panel below the text.

Text near bottom

Display panel above the text.

Text near left edge

Shift panel toward the right.

Text near right edge

Shift panel toward the left.

Text near screen boundary

Clamp panel inside safe display bounds.

The positioning system should avoid:

- Status bar collision
- Navigation bar collision
- Gesture areas
- Display cutouts
- Keyboard obstruction

Support where practical:

- Portrait
- Landscape
- Multi-window
- Foldable layouts

---

11. TRANSLATION WORKFLOW

When the user selects:

Translate

Display a compact translation interface.

Conceptual structure:

Original Text

Target Language
[ English ▼ ]

Translation Result

[ Listen ] [ Copy ]

The translation interface MUST be functional.

It MUST:

- Display the actual detected text.
- Allow target language selection.
- Detect source language when possible.
- Allow manual source-language selection when detection is uncertain.
- Display actual translation results.
- Handle translation progress.
- Handle model preparation.
- Handle model download.
- Handle missing models.
- Handle unsupported language pairs.
- Handle translation failure.

The application MUST never fabricate a translation result.

---

12. ON-DEVICE TRANSLATION

Use a legitimate Android-compatible on-device translation implementation.

A suitable implementation may be Google ML Kit On-Device Translation where appropriate and technically supported.

Core translation MUST NOT depend on:

- Gemini API
- OpenAI API
- ChatGPT API
- Custom cloud AI
- Remote LLM
- Custom translation server

Translation should remain on-device whenever supported.

Required behavior:

Detected Text
      ↓
Check Model
      ↓
Model Available?
   ↙       ↘
 YES       NO
 ↓          ↓
Translate   Model Download
 ↓          ↓
Result      Download Result

The application must correctly handle:

- Model availability.
- Model download.
- Download progress.
- Download failure.
- Network unavailable.
- Offline operation.
- Low storage.
- Unsupported language pairs.
- Translation errors.

No API keys may be embedded in source code.

---

13. OCR REQUIREMENTS

Use real on-device OCR.

Preferred implementation:

Google ML Kit Text Recognition where appropriate.

OCR MUST:

- Process only the required image region whenever practical.
- Detect text blocks.
- Detect lines/elements where supported.
- Obtain bounding boxes where available.
- Support relevant scripts according to the selected OCR implementation.
- Handle rotated text where supported.
- Handle small text as reliably as possible.
- Handle low-quality images gracefully.

OCR MUST NOT run continuously across the entire screen.

If OCR fails:

Text could not be detected.
Please select a clearer text area.

Never fabricate OCR output.

---

14. LISTEN / TEXT-TO-SPEECH

Implement Listen using Android "TextToSpeech".

The system MUST:

- Initialize TTS safely.
- Verify initialization.
- Check language availability.
- Select the appropriate voice/language.
- Allow speech-language configuration.
- Handle unavailable voices.
- Handle initialization failure.
- Stop current speech when a new request starts.
- Provide appropriate playback controls where required.
- Release TTS resources correctly.

Workflow:

Detected Text
      ↓
TextToSpeech
      ↓
Appropriate Language
      ↓
Speaker

Translated text must also be speakable:

Original Text
      ↓
Translation
      ↓
Translated Text
      ↓
Target Language TTS
      ↓
Speaker

No cloud voice generation is required.

---

15. COPY FUNCTIONALITY

Implement real Android clipboard integration using "ClipboardManager".

When the user taps Copy:

Detected/Translated Text
        ↓
Android Clipboard

Show short confirmation:

Copied to clipboard

Clipboard content MUST NOT be permanently stored by the application.

---

16. MAIN APPLICATION UI

Build the application using:

- Kotlin
- Jetpack Compose
- Material 3

The interface must look production-quality.

It MUST NOT resemble a demo project.

Required design qualities:

- Clean typography
- Professional spacing
- Consistent hierarchy
- Rounded components
- Subtle elevation
- Meaningful icons
- Smooth but restrained transitions
- Excellent dark mode
- Excellent light mode
- Accessible contrast
- Responsive layouts

---

17. HOME SCREEN

The Home screen should contain the major product controls.

Header

Include:

- App icon/logo
- App name
- Service status

Example:

Screen Text Assistant
System text assistant

Service Status

Display:

Service Active

or:

Service Disabled

Primary Action

When disabled:

Enable Screen Assistant

When active:

Stop Screen Assistant

The displayed state MUST reflect the actual Android service state.

Never simulate service status.

---

18. HOME SCREEN SECTIONS

The application should provide clear navigation/sections for:

1. Screen Assistant
2. Translate
3. Listen
4. Language
5. Recent Activity, only if implemented according to privacy requirements
6. Settings
7. Permissions
8. Help / How it works

Do not add unrelated product features.

---

19. FIRST-LAUNCH EXPERIENCE

The first-launch flow MUST be professional and understandable.

Required flow:

Splash
   ↓
Welcome
   ↓
Functionality Explanation
   ↓
Privacy Explanation
   ↓
Accessibility Permission
   ↓
Overlay Permission, if required
   ↓
Required Android Setup
   ↓
Service Enabled
   ↓
Home

Sensitive permissions MUST NOT be silently granted or automatically enabled.

The user must explicitly grant required permissions through Android-supported system interfaces.

Before Accessibility access is requested, clearly explain:

«Screen Assistant needs Accessibility access to detect text from supported apps and display the floating tools.»

The application must explain what information is processed and why.

---

20. PRIVACY REQUIREMENTS

Privacy is a core product requirement.

The application MUST NOT:

- Upload screen contents.
- Upload screenshots.
- Upload selected text.
- Send OCR results to a custom server.
- Send translation text to a custom backend.
- Store passwords.
- Store authentication codes.
- Permanently store sensitive screen content.
- Log sensitive text.

Production builds MUST NOT write detected screen text to Logcat.

If temporary screenshots are created:

- Keep them in memory whenever possible.
- Delete temporary files immediately.
- Do not persist screen captures unnecessarily.

---

21. OFFLINE-FIRST REQUIREMENTS

The application must remain useful without internet whenever the required local resources are available.

Offline operation should support:

Accessibility

Continue detecting accessible text.

OCR

Continue OCR if the required OCR implementation/model is available.

TTS

Continue speech if the required voice is installed.

Translation

Continue translation if the required translation model is installed.

If a required model is unavailable:

Display an explicit model-download requirement.

The application MUST NOT silently switch to cloud AI.

---

22. MODEL DOWNLOAD EXPERIENCE

When a translation model must be downloaded, provide a professional model-management UI.

Example:

Language Model

Bengali

Downloading...

████████░░ 80%

Preparing offline translation...

When complete:

✓ Ready for offline use

Handle:

- Download progress.
- Retry.
- Cancellation where supported.
- Network unavailable.
- Download failure.
- Insufficient storage.
- Model preparation failure.

The UI MUST remain responsive.

---

23. SETTINGS

Create a professional Settings screen.

Required settings:

Screen Assistant
[ ON/OFF ]

Default Language
[ Select ]

Translation Target Language
[ Select ]

Speech Language
[ Select ]

Auto Detect Language
[ ON/OFF ]

Floating Panel
[ ON/OFF ]

Show Selection Highlight
[ ON/OFF ]

Speak Automatically
[ ON/OFF ]

Dark Mode
[ System / Light / Dark ]

Clear Local Data

Permissions

Privacy

Help

About

Settings MUST persist through:

- App restart
- Device rotation
- Service restart
- Process recreation

Use an appropriate Android persistence mechanism such as DataStore.

---

24. LANGUAGE ARCHITECTURE

The application MUST support proper Android localization architecture.

At minimum, architecture must be ready for:

- English
- Bengali
- Hindi

All user-facing UI strings MUST use Android resources.

Do NOT hardcode user-facing text inside Compose UI code.

Translation/OCR/TTS language support must reflect the actual capabilities of the selected implementation.

Do not display unsupported languages merely for visual completeness.

---

25. ERROR HANDLING

All major operations MUST have graceful error handling.

Examples:

Accessibility disabled

Screen Assistant is disabled.
Enable Accessibility access to use this feature.

Overlay permission missing

Allow display over other apps to show the floating tools.

OCR failure

No readable text was detected.

Translation model unavailable

Translation language model is not available yet.

Offline without required model

This translation requires the language model to be downloaded first.

TTS unavailable

Speech output is unavailable for this language on this device.

Protected screen

This screen cannot be processed because Android has restricted screen access.

The application MUST NOT expose:

- Stack traces
- Internal exceptions
- Developer terminology
- Raw system errors

to normal users.

---

26. PERFORMANCE REQUIREMENTS

The application must be optimized for Android devices with limited resources.

Requirements:

- No unnecessary background loops.
- No continuous full-screen OCR.
- No memory leaks.
- No unnecessary bitmap retention.
- Release image resources promptly.
- Cancel obsolete OCR jobs.
- Cancel obsolete translation jobs.
- Avoid duplicate TTS initialization.
- Use Kotlin coroutines correctly.
- Use lifecycle-aware components.
- Avoid unnecessary Compose recomposition.
- Avoid unnecessary AccessibilityNode traversal.

The service MUST remain lightweight while idle.

---

27. ANDROID COMPATIBILITY

Target modern Android while maintaining Android 10+ compatibility where technically possible.

The implementation MUST correctly account for API-level differences.

Pay particular attention to:

- AccessibilityService behavior
- Overlay permissions
- Screen capture restrictions
- Foreground-service requirements
- Notification requirements
- Background execution limits
- Android 12+
- Android 13+
- Android 14+
- Android 15+
- Android 16+

Do not use deprecated APIs when supported modern alternatives exist.

When behavior differs between Android versions:

Detect API level
        ↓
Use appropriate implementation
        ↓
Fallback gracefully when necessary

Never claim universal compatibility.

---

28. ARCHITECTURE REQUIREMENTS

Use clean, maintainable production architecture.

Recommended organization:

app/
├── accessibility/
├── overlay/
├── ocr/
├── translation/
├── tts/
├── permissions/
├── settings/
├── data/
├── domain/
├── ui/
│   ├── home/
│   ├── translation/
│   ├── settings/
│   ├── permissions/
│   └── components/
└── utils/

Exact architecture may be adapted if a better production solution is justified.

AccessibilityService MUST NOT contain the entire application business logic.

Use dedicated components where appropriate, such as:

TextDetectionManager
OcrManager
TranslationManager
SpeechManager
OverlayManager
PermissionManager
SettingsRepository

Maintain clear separation of concerns.

---

29. STATE MANAGEMENT

The UI MUST be state-driven.

Example states:

ServiceState

Disabled
Enabling
Active
Error

DetectionState

Idle
Selecting
Detecting
Detected
Failed

TranslationState

Idle
PreparingModel
Translating
Success
Error

SpeechState

Idle
Initializing
Speaking
Paused
Completed
Error

The UI must react to actual state.

Do not manipulate UI through fragile ad-hoc flags.

---

30. ACCESSIBILITY OF THE APPLICATION ITSELF

The application must itself be accessible.

Support:

- TalkBack
- Content descriptions
- Minimum touch target sizes
- Dynamic font scaling
- High contrast
- Screen-reader-friendly labels
- Keyboard navigation where relevant

Do not communicate important information through icons alone.

---

31. ANIMATION REQUIREMENTS

Use subtle professional animations.

Examples:

Detection

Fade + small scale transition.

Floating panel

Small scale-in + fade.

Translation

Progress indicator.

Result

Smooth content transition.

Animations MUST NOT become excessive.

Where practical, respect Android accessibility/reduced-motion preferences.

---

32. RECENT TEXT PRIVACY

Permanent detected-text history MUST NOT be enabled by default.

Default behavior:
No text history.
If a history system is implemented:
User must explicitly enable it.
Store locally only.
Provide Clear All.
Never upload.
Never log sensitive text.
33. SERVICE NOTIFICATION
If the selected Android implementation requires a foreground service or notification, implement it according to the applicable Android version requirements.
Notification should be minimal and clear.
Example:
Screen Assistant

Screen text assistant is active.
Provide an appropriate mechanism to stop the service.
34. PLAY STORE / POLICY REQUIREMENTS
AccessibilityService must be used strictly for the legitimate functionality of this application.
The application MUST NOT use AccessibilityService for:
Automated clicking.
Ad manipulation.
Credential extraction.
Stealth monitoring.
Security bypass.
Unauthorized control of other applications.
The app must clearly disclose why Accessibility access is required.
The implementation must be prepared for the required Accessibility API disclosure/declaration during Play Store submission.
35. NO-FAKE-FUNCTIONALITY RULE
This is a hard requirement.
The following MUST be real:
OCR
Translation
AccessibilityService
Text detection
TTS
Clipboard
Permission state
Service state
Floating interaction
Model availability
Model download state
The application MUST NOT display:
Fake OCR result
Fake translation
Fake service status
Fake permission state
Fake model status
Fake detection
Fake TTS
If a capability is unavailable:
Detect limitation
        ↓
Explain limitation
        ↓
Use legitimate fallback if available
        ↓
Otherwise fail gracefully
36. SECURITY REQUIREMENTS
The application must follow Android security principles.
Never attempt to:
Read passwords.
Extract authentication codes.
Circumvent protected screens.
Capture secure content.
Bypass DRM.
Bypass another app's security mechanisms.
Escalate permissions.
Request unrelated permissions.
Use minimum required permissions.
37. TESTING REQUIREMENTS
A serious QA process is mandatory.
The application should be tested across:
Android 10
Android 11
Android 12
Android 13
Android 14
Android 15
Android 16
Test representative applications and scenarios including:
Web browser
PDF viewer
Messaging application
Social media UI
Android Settings
Web content
Long text
Short text
Large text
Small text
English
Bengali
Hindi
Mixed-language text
Light mode
Dark mode
Portrait
Landscape
Keyboard open
No internet
Slow internet
Missing translation model
TTS unavailable
Accessibility disabled
Overlay disabled
Protected screen
Low-memory conditions
Service restart
Device rotation
Application process death
Verify:
No crashes.
No memory leaks.
No stuck overlay.
No blocked touch interaction.
No duplicate panels.
No duplicate speech.
No endless OCR.
No unnecessary battery drain.
38. BUILD VERIFICATION
The project MUST NOT be considered complete merely because source files were generated.
The agent MUST actually validate the project.
Required verification:
Compile project.
Resolve compilation errors.
Resolve Kotlin errors.
Resolve Gradle errors.
Resolve manifest errors.
Verify Android permissions.
Verify AccessibilityService declaration.
Verify overlay implementation.
Verify OCR pipeline.
Verify translation pipeline.
Verify TTS pipeline.
Verify lifecycle cleanup.
Verify configuration consistency.
Perform release-build verification.
Where tooling permits, perform actual runtime/instrumented testing rather than source-only inspection.
39. UI QUALITY STANDARD
The final application MUST look like a professional production Android utility.
Avoid:
Generic demo UI.
Giant buttons.
Excessive gradients.
Random colors.
Inconsistent spacing.
Placeholder icons.
Debug labels.
Developer terminology.
Excessive animations.
Visually crowded screens.
Use:
Material 3.
Consistent spacing.
Professional typography.
Clear visual hierarchy.
Meaningful icons.
Subtle elevation.
Clean cards.
Responsive layouts.
High-quality dark mode.
Accessible contrast.
The floating interaction must feel polished and system-utility-like.
However, it MUST NOT copy proprietary branding, assets, or copyrighted interface designs.
40. DEVELOPMENT PROCESS
Before implementation, the AI development agent MUST:
Inspect the project structure.
Inspect existing Gradle configuration.
Inspect Android configuration.
Inspect existing dependencies.
Understand the architecture.
Search the provided AI skill library for relevant Android, Compose, Accessibility, OCR, translation, performance, testing, and UI/UX guidance.
Review applicable UI/UX references.
Build an implementation plan.
Implement incrementally.
Validate after each major subsystem.
If the Android project is empty, create the complete project structure.
If an existing project is present, preserve working functionality and integrate the product cleanly.
41. IMPLEMENTATION PHASES
The recommended implementation sequence is:
Phase 1 — Foundation
Project architecture
Gradle configuration
Android configuration
Dependencies
Manifest
Build configuration
Phase 2 — Accessibility
AccessibilityService
Event handling
Node traversal
Text extraction
Bounds detection
Phase 3 — Interaction
Selection workflow
Selection state
Overlay system
Floating panel
Phase 4 — OCR
Screen capture integration where permitted
Image-region processing
OCR
Bounding information
Failure handling
Phase 5 — Translation
Translation engine
Language management
Model availability
Model download
Offline translation
Error handling
Phase 6 — Speech
TextToSpeech
Language handling
Voice availability
Playback state
Lifecycle cleanup
Phase 7 — Application UI
Home
Translation interface
Settings
Permission onboarding
Help
About
Privacy
Phase 8 — Persistence
Settings persistence
Model state where appropriate
Privacy-safe local state
Phase 9 — Performance
Coroutine optimization
Memory optimization
OCR cancellation
Translation cancellation
Service optimization
Phase 10 — QA
Functional testing
Accessibility testing
Lifecycle testing
API-level testing
Edge-case testing
Phase 11 — Release Verification
Debug build
Release build
Manifest verification
Permission verification
Regression review
Final product audit
42. DEFINITION OF DONE
The application is NOT complete when:
UI screens exist.
Buttons exist.
Source code compiles.
Placeholder logic exists.
Mock data produces results.
The application is complete only when the core real-world workflow has been implemented and validated:
Accessibility / permitted screen detection
            ↓
Text identification
            ↓
Selection/detection
            ↓
Floating action panel
            ↓
 ┌──────────┬──────────┬──────────┐
 │ Translate│  Listen  │   Copy   │
 └──────────┴──────────┴──────────┘
            ↓
       Real operation
Translation must produce actual on-device translation when the required model is available.
Listen must produce actual Android TTS speech.
Copy must use the real Android clipboard.
Permission status must reflect real Android state.
Service status must reflect the real AccessibilityService state.
43. FINAL PRODUCT EXPERIENCE
The intended final experience is:
OPEN APPLICATION
      ↓
Professional Welcome
      ↓
Privacy Explanation
      ↓
Required Permission Setup
      ↓
Accessibility Enabled
      ↓
Screen Assistant Active
      ↓
Open Supported Android Application
      ↓
Activate Selection Interaction
      ↓
Select Visible Text
      ↓
Text Detected
      ↓
Floating Action Panel
      ↓
┌─────────────────────────────┐
│ Translate │ Listen │ Copy   │
└─────────────────────────────┘
Translate
Translate
   ↓
Select Target Language
   ↓
Check Translation Model
   ↓
Download if Required
   ↓
On-device Translation
   ↓
Display Result
   ↓
Listen / Copy
Listen
Listen
   ↓
Android TextToSpeech
   ↓
Appropriate Language Voice
   ↓
Speech Output
Copy
Copy
   ↓
Android ClipboardManager
   ↓
Copied to clipboard
44. FINAL TECHNICAL REPORT
After implementation and verification, the AI development agent MUST provide a concise technical report containing:
Implemented functionality.
Android APIs used.
AccessibilityService implementation details.
OCR implementation.
Translation implementation.
TTS implementation.
Which operations work completely offline.
Required language models.
Required Android permissions.
Android API-level compatibility.
Known Android platform limitations.
Devices/API levels tested.
Performance observations.
Remaining issues, if any.
Build result.
Release-build result.
Exact user steps required to enable the Screen Assistant.
The report MUST be factual.
The agent MUST NOT claim successful testing that was not actually performed.
45. FINAL NON-NEGOTIABLE DIRECTIVE
Build this product as a REAL production Android application.
The primary objective is not to generate code.
The primary objective is to deliver a functioning:
SCREEN TEXT
     ↓
DETECTION
     ↓
SELECTION
     ↓
FLOATING TOOLS
     ↓
TRANSLATE / LISTEN / COPY
system using legitimate Android APIs and on-device processing wherever technically possible.
The implementation must be:
Real
Functional
Stable
Professional
Privacy-first
Offline-first
Accessibility-aware
Permission-aware
Resource-efficient
Maintainable
Android-compatible
Security-respecting
Never fake functionality.
Never bypass Android security.
Never silently introduce cloud AI.
Never consider the application finished merely because it compiles.
The final quality standard is a functioning, validated, production-oriented Android application—not a concept, mockup, or prototype.