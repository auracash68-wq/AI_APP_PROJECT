# AI APP PROJECT — MASTER PROCESSING PROTOCOL

## CRITICAL AGENT INSTRUCTION

This directory is the complete knowledge, requirements, design-reference, and workspace package for the Android application.

DO NOT partially process this directory.

Before implementing, modifying, or generating application code, inspect and systematically process the complete project package.

Treat this directory as a structured engineering knowledge base, not as a collection of optional files.

---

## 1. PROJECT OBJECTIVE

Build the Android application according to the project's PRD, requirements, UI/UX references, and applicable professional engineering practices.

The final application must be:

- Production-quality
- Functionally complete
- Professionally designed
- Stable
- Maintainable
- Accessible
- Performant
- Properly tested
- Release-ready

Do not declare the application complete until the implementation has been appropriately verified.

---

## 2. MANDATORY PROJECT SOURCES

The following directories are mandatory sources of information:

01_PROJECT_PRD/
02_UI_UX_REFERENCES/
03_AI_SKILLS_LIBRARY/
04_AGENT_INSTRUCTIONS/
05_ACTUAL_ANDROID_PROJECT/

Process each according to its purpose.

---

## 3. PRD PROCESSING

01_PROJECT_PRD/ is the authoritative product specification.

Before development, identify and understand:

- Product goals
- Features
- Functional requirements
- Non-functional requirements
- User flows
- Business logic
- Constraints
- Platform requirements
- Edge cases
- Acceptance criteria
- Explicit implementation requirements

Do not silently omit difficult, complex, or time-consuming requirements.

---

## 4. UI/UX REFERENCE PROCESSING

02_UI_UX_REFERENCES/ contains product-specific visual and UX references.

Inspect applicable references before designing important screens.

Analyze:

- Layout
- Visual hierarchy
- Typography
- Spacing
- Color system
- Components
- Navigation
- Interaction patterns
- Animation
- Icons
- Loading states
- Empty states
- Error states
- Success states
- Accessibility
- Responsive behavior
- Overall visual language

Use these references to establish the application's visual and interaction direction.

Do not blindly copy another product's copyrighted design.

---

## 5. COMPLETE AI SKILLS LIBRARY

03_AI_SKILLS_LIBRARY/ contains professional engineering, Android, Jetpack Compose, UI/UX, accessibility, design-system, testing, and related knowledge.

Treat ALL repositories inside this directory as available reference sources.

Do not assume that one repository contains everything required.

When a task requires expertise, search across the complete skills library and identify the most relevant sources.

---

## 6. SKILL DISCOVERY PROTOCOL

Before implementing any major feature:

1. Understand the requirement.
2. Identify the technical and/or design problem.
3. Search the relevant areas of 03_AI_SKILLS_LIBRARY/.
4. Inspect all relevant skills, references, documentation, examples, and guidance.
5. Compare relevant sources when multiple sources apply.
6. Resolve conflicting recommendations intelligently.
7. Select the strongest applicable practices.
8. Adapt them to the current application.
9. Implement.
10. Verify the result.

Do not blindly copy source code from reference repositories.

Use the repositories as professional knowledge and reference material.

---

## 7. UI/UX DEVELOPMENT PROTOCOL

For every important screen or user flow, follow:

Requirement
→ User Goal
→ User Flow
→ Information Architecture
→ Visual Hierarchy
→ Design System
→ Component Design
→ Interaction Design
→ Complete UI States
→ Accessibility
→ Implementation
→ Visual Verification

A screen is NOT complete merely because it renders.

Consider applicable:

- Default state
- Loading state
- Empty state
- Error state
- Success state
- Disabled state
- Permission state
- Offline state
- Retry behavior
- Long text
- Small screens
- Large screens
- Font scaling
- Accessibility

---

## 8. ENGINEERING PROTOCOL

Before significant implementation:

1. Inspect the current project state.
2. Understand the architecture.
3. Identify reusable components and utilities.
4. Search the skills library.
5. Create an implementation plan.
6. Implement incrementally.
7. Test.
8. Review for regressions.
9. Build.
10. Fix discovered problems.

Do not unnecessarily rewrite working code.

Do not introduce unnecessary dependencies.

Do not modify unrelated functionality without justification.

---

## 9. FEATURE COMPLETENESS

A feature is complete only when applicable:

UI
+
State
+
Business Logic
+
Data Flow
+
Error Handling
+
Edge Cases
+
Accessibility
+
Testing
+
Build Verification

are implemented and verified.

Do not implement only the visible UI.

Do not implement only the happy path.

---

## 10. ANDROID PROJECT CREATION

If 05_ACTUAL_ANDROID_PROJECT/ is empty, create the complete Android project from scratch according to the PRD and project instructions.

The generated project must contain all required project structure and configuration, including where applicable:

- Gradle configuration
- Gradle Wrapper
- gradlew
- gradlew.bat
- gradle/wrapper/
- gradle-wrapper.jar
- gradle-wrapper.properties
- Android application module
- Source directories
- Resources
- AndroidManifest.xml
- Build configuration
- Required configuration files
- Tests

Do not assume an existing Android project exists.

---

## 11. PRESERVATION RULE

If an existing implementation is present:

PRESERVE WORKING FUNCTIONALITY.

Do not:

- Delete working features
- Rewrite unrelated code
- Remove useful tests unnecessarily
- Redesign unrelated screens
- Replace architecture without justification
- Introduce unnecessary dependencies
- Change unrelated behavior

Every significant modification must be justified by requirements or engineering necessity.

---

## 12. QUALITY ASSURANCE

Before declaring completion, verify:

### PRODUCT

- PRD requirements addressed
- Requested features implemented
- User flows complete
- Business logic implemented
- Important edge cases handled

### UI/UX

- Professional visual hierarchy
- Consistent design system
- Consistent spacing
- Typography consistency
- Correct interaction states
- Loading/empty/error/success states
- Accessibility considered
- Design references appropriately respected

### ENGINEERING

- Architecture is coherent
- Kotlin implementation is maintainable
- Jetpack Compose implementation is appropriate
- State management is correct
- Navigation works
- Data flow works
- Error handling works
- Performance is considered

### QUALITY

- Appropriate tests exist
- Build succeeds
- No obvious crashes
- No unresolved critical errors
- No unfinished placeholder functionality
- No accidental debug-only behavior

---

## 13. NO PREMATURE COMPLETION

Never declare the application complete merely because:

- Code was generated
- Screens were created
- The project opens
- One build succeeded
- The happy path works

Completion requires implementation AND verification.

---

## 14. PRIORITY ORDER

When instructions conflict, use this priority:

1. Explicit Project Requirements
2. PRD
3. Project-specific Agent Instructions
4. UI/UX Requirements and References
5. Applicable Android Best Practices
6. Relevant Skills from the Skills Library
7. General Engineering Best Practices

Do not allow generic preferences to override explicit project requirements.

---

## 15. REPOSITORY SAFETY

Repositories inside 03_AI_SKILLS_LIBRARY/ are reference material.

Do not modify them unless explicitly instructed.

Do not treat them as application dependencies.

Do not automatically copy their complete source code into the Android application.

Use them for:

- Knowledge
- Engineering patterns
- UI/UX methodology
- Design practices
- Architecture guidance
- Examples
- Testing approaches
- Quality practices

---

## 16. MANDATORY FINAL REVIEW

Before completion, verify all applicable questions:

Have I processed the PRD?

Have I inspected the UI/UX references?

Have I searched the AI skills library?

Have I checked relevant multiple sources where appropriate?

Have I implemented every requested feature?

Have I implemented the underlying logic?

Have I handled important edge cases?

Have I handled applicable loading, empty, error, and success states?

Have I considered accessibility?

Have I verified the UI?

Have I tested the functionality?

Have I built the project successfully?

Have I checked for regressions?

Is the application genuinely release-ready?

If any applicable answer is NO:

DO NOT DECLARE THE PROJECT COMPLETE.

Continue working.

---

# FINAL DIRECTIVE

Treat the entire AI_APP_PROJECT/ directory as a professional application-development workspace.

Read broadly before implementing.

Search deeply before deciding.

Use appropriate skills before coding.

Do not skip requirements.

Do not prematurely conclude.

Verify the result.

Build the complete application.

Deliver a professional, stable, tested, release-ready Android application.
